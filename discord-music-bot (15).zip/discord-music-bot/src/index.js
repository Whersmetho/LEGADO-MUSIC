const { Client, GatewayIntentBits, Collection } = require('discord.js');
const { token, spotifyClientId, spotifyClientSecret } = require('../config.json');
const { initSpotify } = require('./spotify');
const fs = require('fs');
const path = require('path');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.MessageContent,
  ],
});

client.commands = new Collection();
client.aliases = new Collection();
client.queues = new Map();

// Cargar comandos y aliases
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'));
for (const file of commandFiles) {
  const command = require(path.join(commandsPath, file));
  client.commands.set(command.name, command);
  if (command.aliases) {
    for (const alias of command.aliases) {
      client.aliases.set(alias, command.name);
    }
  }
}

client.once('ready', () => {
  console.log(`✅ Bot listo: ${client.user.tag}`);
  client.user.setActivity('🎵 l!help para comandos');

  if (spotifyClientId && spotifyClientSecret) {
    initSpotify(spotifyClientId, spotifyClientSecret);
    console.log('🟢 Spotify conectado');
  } else {
    console.warn('⚠️  Credenciales de Spotify no configuradas. Solo YouTube disponible.');
  }
});

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  const prefix = 'l!';
  if (!message.content.toLowerCase().startsWith(prefix)) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const commandName = args.shift().toLowerCase();

  // Buscar por nombre o por alias
  const resolvedName = client.aliases.get(commandName) || commandName;
  const command = client.commands.get(resolvedName);
  if (!command) return;

  try {
    await command.execute(message, args, client);
  } catch (error) {
    console.error(`Error en comando ${commandName}:`, error);
    message.reply('❌ Ocurrió un error ejecutando ese comando.');
  }
});

client.login(token);
